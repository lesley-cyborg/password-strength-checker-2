import re
import os
import hashlib
import requests
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import math

# Load dictionary of common passwords
def load_common_passwords(file_name="samples/weak_passwords.txt"):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(script_dir, file_name)

    try:
        with open(file_path, "r") as f:
            return set(line.strip().lower() for line in f if line.strip())
    except FileNotFoundError:
        return set()

# Check password against HaveIBeenPwned API
def check_pwned_api(password):
    sha1_password = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    prefix = sha1_password[:5]
    suffix = sha1_password[5:]
    url = f"https://api.pwnedpasswords.com/range/{prefix}"

    try:
        response = requests.get(url)
        if response.status_code != 200:
            return False, "⚠️ Error contacting HaveIBeenPwned API."

        hashes = (line.split(':') for line in response.text.splitlines())
        for hash_suffix, count in hashes:
            if hash_suffix == suffix:
                return True, f"❌ Found in {count} breaches!"
        return False, None
    except requests.exceptions.RequestException:
        return False, "⚠️ Network error while checking HIBP."

# Entropy calculation and percentage
def calculate_entropy(password):
    charset = 0
    if re.search(r"[a-z]", password):
        charset += 26
    if re.search(r"[A-Z]", password):
        charset += 26
    if re.search(r"[0-9]", password):
        charset += 10
    if re.search(r"[\W_]", password):
        charset += 32  # Rough estimate for special chars
    entropy = len(password) * math.log2(charset) if charset else 0
    return round(entropy, 2)

def entropy_score(entropy):
    max_entropy = 100  # Cap
    percent = min(int(entropy), max_entropy)
    return percent

# Evaluate password strength
def check_password_strength(password, common_passwords):
    feedback = []

    if len(password) < 8:
        feedback.append("❌ Too short. Use at least 8 characters.")
    if not re.search(r"[A-Z]", password):
        feedback.append("❌ Add at least one uppercase letter.")
    if not re.search(r"[a-z]", password):
        feedback.append("❌ Add at least one lowercase letter.")
    if not re.search(r"[0-9]", password):
        feedback.append("❌ Add at least one number.")
    if not re.search(r"[\W_]", password):
        feedback.append("❌ Add at least one special character (!@#...).")
    if password.lower() in common_passwords:
        feedback.append("❌ Avoid common passwords like 'password', '123456'.")

    leaked, message = check_pwned_api(password)
    if message:
        feedback.append(message)

    if not feedback:
        return "✅ Strong password!", [], calculate_entropy(password)
    else:
        return "⚠️ Weak password.", feedback, calculate_entropy(password)

# GUI Logic
def on_check_password():
    password = password_entry.get()
    if not password:
        messagebox.showwarning("Input Needed", "Please enter a password.")
        return

    result, tips, entropy = check_password_strength(password, common_passwords)
    strength_percent = entropy_score(entropy)

    result_label.config(text=result)
    progress['value'] = strength_percent
    percent_label.config(text=f"{strength_percent}%")

    tips_display.config(state='normal')
    tips_display.delete('1.0', tk.END)

    tips_display.insert(tk.END, f"🔐 Entropy: {entropy} bits\n")
    if tips:
        for tip in tips:
            tips_display.insert(tk.END, f"{tip}\n")
    else:
        tips_display.insert(tk.END, "🎉 Your password looks good!")

    tips_display.config(state='disabled')

def save_report():
    report_text = tips_display.get('1.0', tk.END)
    file_path = filedialog.asksaveasfilename(defaultextension=".txt", title="Save Report", filetypes=[("Text files", "*.txt")])
    if file_path:
        with open(file_path, "w") as f:
            f.write(f"Password Strength Report\n=======================\n")
            f.write(report_text)
        messagebox.showinfo("Saved", "✅ Report saved successfully!")

# Main App
common_passwords = load_common_passwords()

root = tk.Tk()
root.title("🔐 Password Strength Checker")
root.geometry("550x500")
root.configure(bg="#1e1e1e")
root.resizable(False, False)

# Fonts and Colors
FG = "#FFFFFF"
BG = "#1e1e1e"
BTN_BG = "#023B7C"
HIGHLIGHT = "#00cc66"

# Style Widgets
style = ttk.Style()
style.theme_use("clam")
style.configure("TButton", font=("Segoe UI", 11), background=BTN_BG, foreground=FG)
style.configure("TProgressbar", thickness=20, background=HIGHLIGHT)

# UI Layout
tk.Label(root, text="🔑 Enter your password:", font=("Segoe UI", 12), bg=BG, fg=FG).pack(pady=10)
password_entry = tk.Entry(root, show="*", font=("Segoe UI", 12), width=40, bg="#2e2e2e", fg=FG, insertbackground=FG)
password_entry.pack(pady=5)

check_btn = ttk.Button(root, text="Check Password", command=on_check_password)
check_btn.pack(pady=10)

result_label = tk.Label(root, text="", font=("Segoe UI", 12, "bold"), fg=HIGHLIGHT, bg=BG)
result_label.pack()

# Strength Meter
progress = ttk.Progressbar(root, length=400, mode='determinate')
progress.pack(pady=5)
percent_label = tk.Label(root, text="0%", font=("Segoe UI", 10), bg=BG, fg=FG)
percent_label.pack()

# Feedback Box
tips_display = scrolledtext.ScrolledText(root, width=65, height=12, font=("Consolas", 10), bg="#2e2e2e", fg=FG, state='disabled', insertbackground=FG)
tips_display.pack(pady=10)

# Save Button
save_btn = ttk.Button(root, text="💾 Save Report", command=save_report)
save_btn.pack(pady=10)

root.mainloop()
