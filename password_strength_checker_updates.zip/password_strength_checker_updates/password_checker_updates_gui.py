import re
import os
import hashlib
import requests
import tkinter as tk
from tkinter import messagebox, scrolledtext

# Load dictionary of common passwords
def load_common_passwords(file_name="samples/weak_passwords.txt"):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(script_dir, file_name)

    try:
        with open(file_path, "r") as f:
            return set(line.strip().lower() for line in f if line.strip())
    except FileNotFoundError:
        return set()

# Check password against HaveIBeenPwned API
def check_pwned_api(password):
    sha1_password = hashlib.sha1(password.encode('utf-8')).hexdigest().upper()
    prefix = sha1_password[:5]
    suffix = sha1_password[5:]
    url = f"https://api.pwnedpasswords.com/range/{prefix}"

    try:
        response = requests.get(url)
        if response.status_code != 200:
            return False, "⚠️ Error contacting HaveIBeenPwned API."

        hashes = (line.split(':') for line in response.text.splitlines())
        for hash_suffix, count in hashes:
            if hash_suffix == suffix:
                return True, f"❌ Found in {count} breaches!"
        return False, None
    except requests.exceptions.RequestException:
        return False, "⚠️ Network error while checking HIBP."

# Evaluate password strength
def check_password_strength(password, common_passwords):
    feedback = []

    if len(password) < 8:
        feedback.append("❌ Too short. Use at least 8 characters.")
    if not re.search(r"[A-Z]", password):
        feedback.append("❌ Add at least one uppercase letter.")
    if not re.search(r"[a-z]", password):
        feedback.append("❌ Add at least one lowercase letter.")
    if not re.search(r"[0-9]", password):
        feedback.append("❌ Add at least one number.")
    if not re.search(r"[\W_]", password):
        feedback.append("❌ Add at least one special character (!@#...).")
    if password.lower() in common_passwords:
        feedback.append("❌ Avoid common passwords like 'password', '123456'.")

    leaked, message = check_pwned_api(password)
    if message:
        feedback.append(message)

    if not feedback:
        return "✅ Strong password!", []
    else:
        return "⚠️ Weak password.", feedback

# GUI Logic
def on_check_password():
    password = password_entry.get()
    if not password:
        messagebox.showwarning("Input Needed", "Please enter a password.")
        return

    result, tips = check_password_strength(password, common_passwords)
    result_label.config(text=result)
    tips_display.config(state='normal')
    tips_display.delete('1.0', tk.END)

    if tips:
        for tip in tips:
            tips_display.insert(tk.END, f"{tip}\n")
    else:
        tips_display.insert(tk.END, "🎉 Your password looks good!")

    tips_display.config(state='disabled')

# Main App
common_passwords = load_common_passwords()

root = tk.Tk()
root.title("🔐 Password Strength Checker")
root.geometry("500x400")
root.resizable(False, False)

# Input
tk.Label(root, text="Enter a password:", font=("Arial", 12)).pack(pady=10)
password_entry = tk.Entry(root, show="*", font=("Arial", 12), width=40)
password_entry.pack(pady=5)

# Button
check_btn = tk.Button(root, text="Check Password", font=("Arial", 12), command=on_check_password)
check_btn.pack(pady=10)

# Result Label
result_label = tk.Label(root, text="", font=("Arial", 12, "bold"), fg="blue")
result_label.pack()

# Feedback Box
tips_display = scrolledtext.ScrolledText(root, width=60, height=10, font=("Arial", 10), state='disabled')
tips_display.pack(pady=10)

root.mainloop()
